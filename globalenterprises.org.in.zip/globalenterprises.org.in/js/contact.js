function emailSend(){

	var userName = document.getElementById('name').value;
	var phone = document.getElementById('phone').value;
	var email = document.getElementById('email').value;
	var company = document.getElementById('company').value;
	var phonenumber = document.getElementById('phone').value;
	var subject = document.getElementById('subject').value;
	var message = document.getElementById('message').value;
    
	var messageBody = "Name " + userName +
	"<br/> Phone " + phone +
	"<br/> Email " + email +"<br/> company " + company + "<br/> phone " + phonenumber +"<br/> subject " + subject +"<br/> message " + message;
	Email.send({
    Host : "smtp.elasticemail.com",
    Username : "karthikgowdara198@gmail.com",
    Password : "39B61FD4F7B5E2FE173FC706F20F1933DFF9",
    To : 'murthyraja27@gmail.com',
    From : "wecare@financeboss.im",
    Subject : "This is the subject",
    Body : messageBody
}).then(
  message => {
  	if(message=='OK'){
  		swal("Secussful", "You clicked the button!", "success");
  	}
  	else{
  		swal("Error", "You clicked the button!", "error");
  	}
  }
);
}
